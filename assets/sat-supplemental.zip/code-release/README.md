# This is the box convolution implementation used in the paper: "Accelerating Large-Kernel Convolution Using Summed-Area Tables"

## Dependencies
* PyTorch 1.1.0
* CUDA 9.0 (NVCC for compiling CUDA)

## Quick Start
1. We recommend using conda to install PyTorch:
    ```
    conda install pytorch torchvision cudatoolkit=9.0 -c pytorch
    ```
2. Compile the package
    ```
    cd box_conv
    python setup.py build develop
    cd ..
    ```
3. Run the demo
    ```
    python demo.py
    ```
    The demo runs both the python implementation (slow) and the CUDA implementation. The results are expected to be consistent.
