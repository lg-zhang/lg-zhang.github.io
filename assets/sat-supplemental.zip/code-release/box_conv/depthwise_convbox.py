import torch
from torch import nn
from torch.nn import functional as F
from torch.autograd import Function
from torch.autograd.function import once_differentiable

import math
from time import time

from .py_dw_convbox import _depthwise_convbox_impl
from . import _C


class _SpatialDepthwiseBoxFilterConvolution(Function):
    @staticmethod
    def forward(
        ctx,
        sat,
        weight,
        bias,
        sample_loc,
        ksize,
        stride,
        pad
    ):
        # check whether contiguous
        assert sat.is_contiguous()
        assert weight.is_contiguous()
        assert sample_loc.is_contiguous()

        # compute sizes
        N, _, H_in, W_in = sat.size()
        C = weight.size(0)
        H_out = (H_in + pad * 2 + 1 - ksize) // stride + 1
        W_out = (W_in + pad * 2 + 1 - ksize) // stride + 1

        # save temp tensors
        ctx.save_for_backward(
            sat,
            sample_loc,
            weight
        )
        ctx.ksize = ksize
        ctx.stride = stride
        ctx.pad = pad
        ctx.bias_enabled = True if bias.numel() else False

        # create output buffer
        output = torch.zeros(
            (N, C, H_out, W_out),
            dtype=sat.dtype,
            device=sat.device
        )

        if str(sat.device) == 'cpu':
            print('WARNING: CPU implementation not available now')
            return output

        # call C api
        _C.spatial_depthwise_boxconv_forward(
            sat,
            sample_loc,
            weight,
            bias,
            ctx.ksize,
            ctx.stride,
            ctx.pad + 1,  # +1 because SAT needs padding
            output
        )

        return output

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        # retrieve saved tensors
        sat, sample_loc, weight = ctx.saved_tensors

        if not grad_output.is_contiguous():
            grad_output = grad_output.contiguous()
        assert grad_output.is_contiguous()
        assert sample_loc.is_contiguous()
        assert weight.is_contiguous()

        # create summed area table gradient buffer
        grad_sat = torch.zeros(
            sat.size(),
            dtype=grad_output.dtype,
            device=grad_output.device
        )

        # create weight gradient buffer
        grad_weight = torch.zeros(
            weight.size(),
            dtype=grad_output.dtype,
            device=grad_output.device
        )

        # call C api
        _C.spatial_depthwise_boxconv_backward(
            sat,
            sample_loc,
            weight,
            grad_output,
            ctx.ksize,
            ctx.stride,
            ctx.pad + 1,
            grad_sat,
            grad_weight
        )

        if ctx.bias_enabled:
            grad_bias = grad_output.sum(3).sum(2).sum(0)
        else:
            grad_bias = None

        # number of input arguments == number of output values
        return grad_sat, grad_weight, grad_bias, None, None, None, None


_spatial_depthwise_boxconv_func = _SpatialDepthwiseBoxFilterConvolution.apply


class SpatialDepthwiseBoxFilterConvolution(nn.Module):
    def __init__(
        self,
        num_boxes,
        num_channels,
        kernel_size,
        stride=1,
        padding=0,
        bias=True,
        use_py_impl=False,
        learn_box_location=True,
        learn_box_weight=True,
        sigmoid_mapping=False,
        normalize=False,
    ):
        super(SpatialDepthwiseBoxFilterConvolution, self).__init__()

        self.ksize = kernel_size
        self.stride = stride
        self.padding = padding
        self.learn_box_location = learn_box_location
        self.learn_box_weight = learn_box_weight
        self.learn_bias = bias
        self.py_impl = use_py_impl
        self.normalize = normalize

        box_params = torch.empty(
            num_channels,
            num_boxes,
            4,
        )

        box_params.uniform_(-0.5, 0.5)
        a = torch.min(box_params[..., :2], box_params[..., 2:])
        b = torch.max(box_params[..., :2], box_params[..., 2:])
        box_params[..., :2] = a
        box_params[..., 2:] = b

        if not learn_box_location:
            self.register_buffer("boxes", box_params)
        else:
            self.boxes = nn.Parameter(box_params)

        if not learn_box_weight:
            self.weight = 1.0
        else:
            self.weight = nn.Parameter(torch.zeros(num_channels, num_boxes))
            nn.init.normal_(self.weight, std=0.001)

        if bias:
            self.bias = nn.Parameter(torch.zeros(num_channels))
        else:
            self.bias = torch.empty(0)

        if not learn_box_weight and not learn_box_location:
            sample_loc = torch.zeros((num_channels, num_boxes, 4, 2))
            weight_final = torch.zeros((num_channels, num_boxes, 4))
        else:
            sample_loc = torch.zeros((num_channels, num_boxes, 16, 2))
            weight_final = torch.zeros((num_channels, num_boxes, 16))

        self.register_buffer("sample_loc", sample_loc)
        self.register_buffer("weight_final", weight_final)

        # if static box, reparameterize only once
        if not learn_box_weight and not learn_box_location:
            self.convert_params_int_coords(kernel_size)

    def convert_params_int_coords(self, ksize):
        x_min, y_min, x_max, y_max = self._reparameterize(ksize)

        idx = 0
        for y_idx, x_idx in ((0, 0), (0, 1), (1, 0), (1, 1)):
            if y_idx == 0:
                sample_y = y_min
            else:
                sample_y = y_max

            if x_idx == 0:
                sample_x = x_min
            else:
                sample_x = x_max

            xx = sample_x.round().detach()
            yy = sample_y.round().detach()

            sign = 1.0 if y_idx == x_idx else -1.0

            self.sample_loc[..., idx, 0] = xx
            self.sample_loc[..., idx, 1] = yy
            self.weight_final[..., idx] = sign
            idx += 1

    def convert_params(self, ksize):
        x_min, y_min, x_max, y_max = self._reparameterize(ksize)

        self.sample_loc = self.sample_loc.detach()
        self.weight_final = self.weight_final.detach()

        if self.normalize:
            scale = 1.0 / ((x_max - x_min) * (y_max - y_min))
        else:
            scale = 1.0

        idx = 0
        for y_idx, x_idx in ((0, 0), (0, 1), (1, 0), (1, 1)):
            if y_idx == 0:
                sample_y = y_min
            else:
                sample_y = y_max

            if x_idx == 0:
                sample_x = x_min
            else:
                sample_x = x_max

            x_lo = sample_x.floor().detach().clamp(min=0)
            x_hi = (x_lo + 1).clamp(max=ksize)
            y_lo = sample_y.floor().detach().clamp(min=0)
            y_hi = (y_lo + 1).clamp(max=ksize)

            x_alpha = sample_x - x_lo
            y_alpha = sample_y - y_lo

            sign = scale if y_idx == x_idx else -scale
            # y_lo, x_lo
            self.sample_loc[..., idx, 0] = x_lo
            self.sample_loc[..., idx, 1] = y_lo
            self.weight_final[..., idx] = \
                (1 - y_alpha) * (1 - x_alpha) * self.weight * sign
            idx += 1

            # y_lo, x_hi
            self.sample_loc[..., idx, 0] = x_hi
            self.sample_loc[..., idx, 1] = y_lo
            self.weight_final[..., idx] = \
                (1 - y_alpha) * x_alpha * self.weight * sign
            idx += 1

            # y_hi, x_lo
            self.sample_loc[..., idx, 0] = x_lo
            self.sample_loc[..., idx, 1] = y_hi
            self.weight_final[..., idx] = \
                y_alpha * (1 - x_alpha) * self.weight * sign
            idx += 1

            # y_hi, x_hi
            self.sample_loc[..., idx, 0] = x_hi
            self.sample_loc[..., idx, 1] = y_hi
            self.weight_final[..., idx] = \
                y_alpha * x_alpha * self.weight * sign
            idx += 1

    def forward(self, x):
        # compute summed-area table
        sat = x.cumsum(3).cumsum(2)

        if self.learn_box_weight or self.learn_box_location:
            self.convert_params(self.ksize)

        if not self.py_impl:
            _impl_func = _spatial_depthwise_boxconv_func
        else:
            _impl_func = _depthwise_convbox_impl

        y = _impl_func(
            sat,
            self.weight_final,
            self.bias,
            self.sample_loc,
            self.ksize + 1,  # +1 because of SAT pads top and left
            self.stride,
            self.padding
        )

        return y

    def _reparameterize(self, ksize):
        if self.boxes.grad is not None:
            self.boxes.grad.zero_()
        return self._reparameterize_clipping(ksize)

    def _reparameterize_clipping(self, ksize):
        half = (ksize - 1.0) / 2.0

        # clip out-of-boundary values
        self.boxes.data.clamp_(min=-1.0, max=1.0)

        # reset negative boxes
        neg_size = self.boxes[..., :2] > self.boxes[..., 2:]
        self.boxes.data[..., :2][neg_size] = 0
        self.boxes.data[..., 2:][neg_size] = 0
        if self.boxes.grad is not None:
            self.boxes.grad[..., :2][neg_size] = 0
            self.boxes.grad[..., 2:][neg_size] = 0

        converted = half * (1.0 + self.boxes)

        x_min = converted[..., 0]
        y_min = converted[..., 1]
        x_max = converted[..., 2]
        y_max = converted[..., 3]

        return x_min, y_min, x_max + 1.0, y_max + 1.0

    def __repr__(self):
        tmpstr = self.__class__.__name__ + "("
        tmpstr += "num_channels=" + str(self.boxes.size(0))
        tmpstr += ", num_boxes=" + str(self.boxes.size(1))
        tmpstr += ", bias=" + \
            ("True" if self.learn_bias else "False")
        tmpstr += ", learn_box_location=" + \
            ("True" if self.learn_box_location else "False")
        tmpstr += ", learn_box_weight=" + \
            ("True" if self.learn_box_weight else "False")
        tmpstr += ", py_impl=" + \
            ("True" if self.py_impl else "False")
        tmpstr += ")"
        return tmpstr
