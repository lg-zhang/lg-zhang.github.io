#pragma once

#include <THC.h>
#include <THCGeneral.h>

#ifdef WITH_CUDA
#include "cuda/DepthwiseConvBox_cuda.h"
#endif


void SpatialDepthwiseBoxFilterConvolution_forward(
  const at::Tensor& SAT,
  const at::Tensor& sampleLoc,
  const at::Tensor& weight,
  const at::Tensor& bias,
  const int ksize,
  const int stride,
  const int pad,
  at::Tensor& output
) {
  if (SAT.type().is_cuda()) {
#ifdef WITH_CUDA
    SpatialDepthwiseBoxFilterConvolution_forward_cuda (
      SAT,
      sampleLoc,
      weight,
      bias,
      ksize,
      stride,
      pad,
      output
    );
    return;
#else
    AT_ERROR("Not compiled with GPU support");
#endif
  }

  // TODO CPU
  AT_ERROR("Not compiled with CPU support");  
}


void SpatialDepthwiseBoxFilterConvolution_backward(
  const at::Tensor& SAT,
  const at::Tensor& sampleLoc,
  const at::Tensor& weight,
  const at::Tensor& grad_output,
  const int ksize,
  const int stride,
  const int pad,
  at::Tensor& grad_SAT,
  at::Tensor& grad_weight
) {
  if (SAT.type().is_cuda()) {
#ifdef WITH_CUDA
    SpatialDepthwiseBoxFilterConvolution_backward_cuda (
      SAT,
      sampleLoc,
      weight,
      grad_output,
      ksize,
      stride,
      pad,
      grad_SAT,
      grad_weight
    );
    return;
#else
    AT_ERROR("Not compiled with GPU support");
#endif
  }

  // TODO CPU
  AT_ERROR("Not compiled with CPU support");  
}