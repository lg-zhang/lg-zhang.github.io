#pragma once
#include <torch/extension.h>


void SpatialDepthwiseBoxFilterConvolution_forward_cuda(
  const at::Tensor& SAT,
  const at::Tensor& sampleLoc,
  const at::Tensor& weight,
  const at::Tensor& bias,
  const int ksize,
  const int stride,
  const int pad,
  at::Tensor& output);


void SpatialDepthwiseBoxFilterConvolution_backward_cuda(
  const at::Tensor& SAT,
  const at::Tensor& sampleLoc,
  const at::Tensor& weight,
  const at::Tensor& grad_output,
  const int ksize,
  const int stride,
  const int pad,
  at::Tensor& grad_SAT,
  at::Tensor& grad_weight);