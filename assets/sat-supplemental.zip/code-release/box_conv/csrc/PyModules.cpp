#include "DepthwiseConvBox.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def(
    "spatial_depthwise_boxconv_forward", 
    &SpatialDepthwiseBoxFilterConvolution_forward, 
    "SpatialDepthwiseBoxFilterConvolution_forward"
  );
  m.def(
    "spatial_depthwise_boxconv_backward", 
    &SpatialDepthwiseBoxFilterConvolution_backward, 
    "SpatialDepthwiseBoxFilterConvolution_backward"
  );
}
