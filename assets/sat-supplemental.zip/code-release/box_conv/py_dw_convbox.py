# This is the python implementation (slow). For verification purpose only.
import torch
import torch.nn.functional as F
from torch import nn


def _depthwise_convbox_impl(
    sat,
    weights,
    bias,
    sample_loc,
    ksize,
    stride,
    pad
):

    if pad > 0:
        sat = torch.cat(
            (sat, sat[..., sat.size(3) - 1:].repeat(1, 1, 1, pad)), dim=3)
        sat = torch.cat(
            (sat, sat[..., sat.size(2) - 1:, :].repeat(1, 1, pad, 1)), dim=2)

    # pad left and top
    sat = F.pad(sat, (pad + 1, 0, pad + 1, 0))

    # compute sizes
    N, _, H_in, W_in = sat.size()
    C, _, _ = weights.size()
    H_out = (H_in - ksize) // stride + 1
    W_out = (W_in - ksize) // stride + 1

    # create output buffer
    output = torch.zeros(
        (N, C, H_out, W_out),
        dtype=sat.dtype,
        device=sat.device
    )

    for elt in range(N):
        for C_idx in range(C):
            b = bias[C_idx] if bias.numel() else 0
            for y in range(H_out):
                for x in range(W_out):
                    offsets = sample_loc[C_idx, ...]
                    w = weights[C_idx, ...]

                    xx = x * stride + offsets[..., 0].long()
                    yy = y * stride + offsets[..., 1].long()

                    output[elt, C_idx, y, x] = \
                        (sat[elt, C_idx, yy, xx] * w).sum() + b

    return output
