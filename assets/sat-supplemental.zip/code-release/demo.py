import os
import os.path
import copy
import torch
import torch.nn as nn
from box_conv import SpatialDepthwiseBoxFilterConvolution


def main():
    def to_cpu(x):
        return x.detach().to('cpu').clone()

    config = {
        'num_boxes': 2,
        'num_channels': 4,
        'kernel_size': 31,
        'stride': 2,
        'padding': 15,
        'bias': True,
        'learn_box_weight': False,
        'learn_box_location': True,
    }

    if not os.path.exists('gt.pt'):
        print('Running python implementation (slow)')
        convbox = SpatialDepthwiseBoxFilterConvolution(
            **config,
            use_py_impl=True
        )
        print(convbox)
        convbox = convbox.cuda()

        # initialize random data
        data = torch.empty(3, 4, 64, 64).uniform_(-10.0, 10.0)

        # forward and backprop
        x = copy.deepcopy(data).cuda().requires_grad_(True)
        out_py = convbox(x)
        dummy_loss = out_py.sum()
        dummy_loss.backward()

        # save the results
        gt = {
            'x': data,
            'y': to_cpu(out_py),
            'x_grad': to_cpu(x.grad),
            'boxes': to_cpu(convbox.boxes.data),
            'bias': to_cpu(convbox.bias.data),
        }

        if convbox.learn_box_weight:
            gt['weight_grad'] = to_cpu(convbox.weight.grad)
            gt['weight'] = to_cpu(convbox.weight.data)

        if convbox.learn_box_location:
            gt['boxes_grad'] = to_cpu(convbox.boxes.grad)

        if convbox.learn_bias:
            gt['bias_grad'] = to_cpu(convbox.bias.grad)

        torch.save(gt, 'gt.pt')
    else:
        # load precomputed results
        gt = torch.load('gt.pt')

    def print_diff(py_res, gpu_res, name, max_samples=5):
        py_res = py_res.view(-1).data
        gpu_res = gpu_res.view(-1).data

        res_diff = (py_res - gpu_res).abs()
        print('\nChecking variable "{}":'.format(name))
        print('\t|py - gpu|: max= {:.4e}, avg= {:.4e}'.format(
            res_diff.max(),
            res_diff.mean()
        ))

        if max_samples is not None:
            # print a few values
            print('A few values for spot checking:')
            print('\tgpu samples = {}'.format(
                gpu_res[:min(max_samples, len(gpu_res))].tolist()
            ))
            print('\tpy  samples = {}'.format(
                py_res[:min(max_samples, len(py_res))].tolist()
            ))

    print('Running CUDA implementation')
    convbox = SpatialDepthwiseBoxFilterConvolution(**config, use_py_impl=False)
    print(convbox)

    convbox.boxes.data = gt['boxes']
    if convbox.learn_box_weight:
        convbox.weight.data = gt['weight']
    if convbox.learn_bias:
        convbox.bias.data = gt['bias']

    # redo conversion since parameters are manually changed
    if not convbox.learn_box_weight and not convbox.learn_box_location:
        convbox.convert_params_int_coords(convbox.ksize)

    convbox = convbox.cuda()

    # test multi-gpu functionality
    convbox = nn.DataParallel(convbox)

    # run at least twice
    for _ in range(2):
        x = copy.deepcopy(gt['x']).cuda().requires_grad_(True)
        out_cu = convbox(x)
        dummy_loss = out_cu.sum()

        # clear grad for the next iteration
        for p in convbox.parameters():
            if p.grad is not None:
                p.grad.detach_()
                p.grad.zero_()

        dummy_loss.backward()

    out_cu = to_cpu(out_cu)
    x_grad_cu = to_cpu(x.grad)

    out_py = gt['y']
    x_grad_py = gt['x_grad']
    print_diff(out_py, out_cu, 'y')
    print_diff(x_grad_py, x_grad_cu, 'x.grad')

    if convbox.module.learn_box_weight:
        weight_grad_cu = to_cpu(convbox.module.weight.grad)
        weight_grad_py = gt['weight_grad']
        print_diff(weight_grad_py, weight_grad_cu, 'weight.grad')

    if convbox.module.learn_box_location:
        boxes_grad_cu = to_cpu(convbox.module.boxes.grad)
        boxes_grad_py = gt['boxes_grad']
        print_diff(boxes_grad_py, boxes_grad_cu, 'boxes.grad')

    if convbox.module.learn_bias:
        bias_grad_cu = to_cpu(convbox.module.bias.grad)
        bias_grad_py = gt['bias_grad']
        print_diff(bias_grad_py, bias_grad_cu, 'bias.grad')


if __name__ == '__main__':
    main()
